package com.cg.tms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tms.entity.Trainee;
import com.cg.tms.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	TraineeService tser;

	@RequestMapping("home")
	public String goHome(Model model){
		List <Trainee> tlist= tser.getAllTrainee();
		model.addAttribute("tlist",tlist);
		model.addAttribute("trainee",new Trainee());
		return "Register";
	}
	
	
	@RequestMapping("register")
	public String register(@ModelAttribute("trainee") @Valid Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			List <Trainee> tlist= tser.getAllTrainee();
			model.addAttribute("tlist",tlist);
			model.addAttribute("trainee", trainee);
			return "Register";
		}
		else{
			long traineeid=tser.inseerttrainee(trainee);
			model.addAttribute("traineeid",traineeid);
			return "Success";
		}
	}
	
	@RequestMapping("deletepage")
	public String delete(Model model){
		model.addAttribute("id",new Trainee());
		return "Delete";
	}
	
	
	@RequestMapping("delete")
	public String deletetrainee(Model model, @RequestParam("del") Integer traineeId){
		tser.delete(traineeId);
		model.addAttribute("msg","Delete ");
		return "DeleteSuccess";
	}
	@RequestMapping("viewall")
	public String viewall(Model model, Trainee trainee){
		List <Trainee> tlist= tser.getAllTrainee();
		model.addAttribute("tlist",tlist);
		model.addAttribute("trainee", trainee);
		return "Viewall";
	}
}
