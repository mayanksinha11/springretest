package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.entity.Trainee;

public interface TraineeDao {
	
	long inseerttrainee(Trainee trainee);
	List<Trainee> getAllTrainee();
	void delete(Integer traineeId);
}
