package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tms.entity.Trainee;
@Repository
public class TraineeDaoImpl implements TraineeDao {
@PersistenceContext
EntityManager em;
	@Override
	public long inseerttrainee(Trainee trainee) {
		em.persist(trainee);
		return trainee.getTraineeId();
	}

	@Override
	public List<Trainee> getAllTrainee() {
		String jpql="SELECT trainee from Trainee trainee";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}

	@Override
	public void delete(Integer traineeId) {
		Trainee train=em.find(Trainee.class, traineeId);
		em.remove(train);
	}

}
