package com.cg.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tms.dao.TraineeDao;
import com.cg.tms.entity.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	TraineeDao tdao;
	public TraineeDao getTdao() {
		return tdao;
	}

	public void setTdao(TraineeDao tdao) {
		this.tdao = tdao;
	}

	@Override
	public long inseerttrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return tdao.inseerttrainee(trainee);
	}

	@Override
	public List<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		return tdao.getAllTrainee();
	}

	@Override
	public void delete(Integer traineeId) {
	tdao.delete(traineeId);
		
	}

	
	
	
}
