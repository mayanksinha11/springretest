package com.cg.hrb.service;

import java.util.List;

import com.cg.hrb.entity.BookingDetails;
import com.cg.hrb.entity.HotelDetails;

public interface IBookingService {
	long insertBookingDetails(BookingDetails book);
	List<HotelDetails> getAllHotels();
}
