package com.cg.hrb.service;

import java.util.List;

import com.cg.hrb.entity.BookingDetails;
import com.cg.hrb.entity.Hotel;

public interface IBookingService {
	long insertBookingDetails(BookingDetails book);
	List<Hotel> getAllHotels();
}
