package com.cg.hrb.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.hrb.entity.BookingDetails;
import com.cg.hrb.entity.HotelDetails;
@Repository
public class BookingDaoImpl implements IBookingDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public long insertBookingDetails(BookingDetails book) {
		em.persist(book);
		return book.getId();
	}

	@Override
	public List<HotelDetails> getAllHotels() {
		
		
		String jpql="Select hoteldetails from HotelDetails hoteldetails";
		TypedQuery<HotelDetails> query=em.createQuery(jpql,HotelDetails.class);
			
			return query.getResultList();
		
	}

}
